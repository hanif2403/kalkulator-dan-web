<?php
require_once('Head.php');
require_once('Header.php');
require_once('Konten.php');
require_once('Footer.php');

?>
