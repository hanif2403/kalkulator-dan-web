<div class="Konten">
 <div class="slider"><img src="<?php echo base_url(); ?>asset/images/M.jpg" width="624"
height="326"></div>
 <div class="anggota">
 <h3>Login Administrator</h3>
 <form name="form2" method="POST" action="/dyah/index.php">
 <p>
 <label for="email">Username (email)</label>
 <input type="text" name="email" id="email">
 </p>
 <p>
 <label for="password">Password</label>
 <input type="password" name="password" id="password">
 </p>
 <p>
 <input type="submit" name="submit2" id="submit2" value="Masuk">
 <input type="reset" name="submit3" id="submit3" value="Reset">
 </p>
 <!--<p><a href="lohin.php?ref=lupa">Lupa password?</a> | <a href="daftar.php">Daftar jadi
anggota</a></p>-->
 </form>
 </div>
 </div>
 <!-- konten bawah -->
 <div class="clearfix"></div>
 <div class="konten">
 <div class="posting">
 <h3>Berita terbaru</h3>

 <div class="ringkasan">
 <p>LAB TI</p>
 <ul>
 <li>Minggu terakhir praktikum</li> </ul>
 </div>
 </div>
 <div class="anggota">
 <h3>Berita terbaru</h3>
 <ul>
 <li><a href="#">Lorem ipsum dolor sit amet</a></li>
 <li><a href="#">Consectetur adipisicing elit</a></li>
 <li><a href="#">Sed do eiusmod tempor incididunt</a></li>
 <li><a href="#">Ut labore et dolore magna aliqua</a></li>
 <li><a href="#">Ut enim ad minim veniam</a></li>
 <li><a href="#">Quis nostrud exercitation</a></li>
 <li><a href="#">Ullamco laboris nisi</a></li>
 <li><a href="#">Ut aliquip ex ea commodo consequat</a></li>
 <li><a href="#">Duis aute irure dolor</a></li>
 <li><a href="#">In reprehenderit in voluptate</a></li>
 <li><a href="#">Velit esse cillum dolore</a></li>
 <li><a href="#">Eu fugiat nulla pariatur</a></li>
 <li><a href="#">Excepteur sint occaecat</a></li>
 <li><a href="#">Cupidatat non proident</a></li>
 <li><a href="#">Sunt in culpa</a></li>
 </ul>
<p>&nbsp;</p>
 <p>
 </p>
 </div>
 </div>